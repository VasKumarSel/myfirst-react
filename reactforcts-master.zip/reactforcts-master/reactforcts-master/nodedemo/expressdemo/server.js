var express = require('express')
var bodyParser = require('body-parser')
var cors = require('cors')
var app = express()


app.use(cors());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
 
var todos= ["Tamil","Guru"]
var det = []

app.get('/todo', function (req, res) {
  res.json(todos);
})

app.post('/todo', function (req, res) {
    var tds = req.body

    todos.push(tds.name,tds.name1)
    res.json(todos);
  })

// app.delete('/todos',function(req,res){
//   console.log("Deleted")
//   res.send("hello world");
// })
app.post('/app', function (req, res) {
  var id = req.body.id
  var pwd = req.body.pwd
  if(id == pwd){
    res.json({get: true})
  }
  else{
    res.json({get:false});
  }
})

app.delete('/del_user', function (req, res) {
  console.log("Got a DELETE request for /del_user");
  res.json(todos);
})
app.get('/weather', function (req, res) {
  res.json({"currentTemp" : 25})
})

app.post('/', function (req, res) {
    res.send('Hello World')
  })
 
app.listen(4000)