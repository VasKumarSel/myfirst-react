import React, {Component} from "react";

class ListItems extends Component{

    handleItems(){
        this.props.whenClick(this.props.text)
    }
    render(){
        return(
            <div>
                <li onClick={this.handleItems.bind(this)}  class="list-group-item">{this.props.text}</li>
            </div>    
        );
    }
}

export default ListItems;