import React, { Component } from 'react';

class Profile extends Component {
    // componentWillMount() {
    //     console.log('CWM', this.props.match.params.name);
    // }
    render() {
        //console.log(this.props.match.params)
        return (
            <div>
                <h1>Logged Successfully</h1>
            </div>
        );
    }
}

export default Profile
