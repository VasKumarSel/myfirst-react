import React, { Component } from 'react';

class Error extends Component {
    
    render() {
        //console.log(this.props.match.params)
        return (
            <div>
                <h1>Sorry..Try Again!!!</h1>
            </div>
        );
    }
}

export default Error
