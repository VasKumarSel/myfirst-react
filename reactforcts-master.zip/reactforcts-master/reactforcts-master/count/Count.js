'use strict';

var count = React.createClass({
    displayName: 'count',
    render: function render() {
        return React.createElement(
            'div',
            null,
            React.createElement(
                'h2',
                null,
                'Hii bddy'
            )
        );
    }
});

var obj = React.createElement(count, {});

ReactDOM.render(obj, document.getElementById('root'));