

var count = React.createClass({
    getInitialState: function getInitialState() {
        console.log('Set Initial State');
        return { count: 0,
        val = {} };
    },
    
    incrementCount: function incrementCount() {
        console.log('click event captured..');
        var newcount = this.state.count + 1;
        this.setState({ count: newcount });
    },
    update: function update() {
        var root = "http://192.168.1.3:8080/reactforcts-master/count/count.json";
        $.ajax({
            url: root,
            method: 'GET'
        }).then(function (data) {
            this.state.val = data.count;
        });

        console.log(this.state);
    },
    render(){
        return(
            <div>
            <h2>Hii bddy dgfsgf</h2>
            <h1>dhjfhd</h1>
            <button onClick={this.incrementCount}>Hii</button>
             <button onClick={this.update}>{this.state.val}</button>
            </div>
        );
    }
})

var obj = React.createElement(count,{})

ReactDOM.render(obj,document.getElementById('root'))