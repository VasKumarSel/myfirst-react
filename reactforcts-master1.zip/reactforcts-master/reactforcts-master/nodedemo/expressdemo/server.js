var express = require('express')
var bodyParser = require('body-parser')
var cors = require('cors')
var app = express()


app.use(cors());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
 
var todos= [
  {   "id": 1, 
  "firstname": "Kamal",
"lastname": "Haasan",
"image": "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201707/kamal-hassan_647_082116071527_071917115444_0.jpg",
  "link": "http://iviewsource.com",
  "description": "Universal Star"
},
{   "id": 2, 
  "firstname": "Rajni",
"lastname": "Kanth",
"image": "https://qph.ec.quoracdn.net/main-qimg-5a353a8bfa444ea870255168df837648.webp",
  "link": "http://iviewsource.com",
  "description": "Super Star"
} ,
{   "id": 3, 
  "firstname": "Ajith",
"lastname": "Kumar",
"image": "http://www.ajithfans.com/article-uploads/2008/11/ajith-kumar.jpg",
  "link": "http://iviewsource.com",
  "description": "Ultimate Star"
}   

]
var det = []

app.get('/todo', function (req, res) {
  res.json(todos);
})

app.post('/todo', function (req, res) {
    var tds = req.body

    todos.push(tds.name,tds.name1)
    res.json(todos);
  })

// app.delete('/todos',function(req,res){
//   console.log("Deleted")
//   res.send("hello world");
// })
app.post('/app', function (req, res) {
  var id = req.body.id
  var pwd = req.body.pwd
  if(id == pwd){
    res.json({get: true})
  }
  else{
    res.json({get:false});
  }
})

app.delete('/del_user', function (req, res) {
  console.log("Got a DELETE request for /del_user");
  res.json(todos);
})
app.get('/weather', function (req, res) {
  res.json({"currentTemp" : 25})
})

app.post('/', function (req, res) {
    res.send('Hello World')
  })
 
app.listen(4000)