import React from 'react';
import ReactDOM from 'react-dom';


class App extends React.Component{
    render(){
        return(<div>Vaanth</div>)
    }
}

export default App

var obj = React.createElement(App, {});

ReactDOM.render(<App/>,document.getElementById('redux'))