import fetch from 'isomorphic-fetch';
import axios from 'axios';

function fetchData(){
    axios.get("http://localhost:4000/todo")
    .then(function(response){
        console.log(response)
    })
    .catch(function(error){
        console.log(error)
    })
}

export const get = (users)=>{
    console.log("the name is",users)
    return{
        type: "GET",
        payload: users
    }
}

export function loadData(){
    return (dispatch)=>{
        return axios.get("http://localhost:4000/todo").then(users=>{
            dispatch(get(users));
            console.log(users)
        })
        .catch((error)=>{
            throw(error)
        })
    }
}