export const getDetails = (state={},action) => {
    switch(action.type){
        case "GET":
        return action.payload;
        break;
    }
    return state;
}