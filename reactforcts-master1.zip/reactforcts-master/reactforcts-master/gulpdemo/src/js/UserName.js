import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {get} from '../actions/actions'

class UserName extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        var list = this.props.users.map((user)=>(<li  onClick={()=>this.props.get(user)}  key={user.id}>{user.firstname} {user.lastname} </li>))
        return(
            <div>
                <ul>
                    <li>{list}</li>
                    <h1></h1>
                </ul>
            </div>
        )
    }
}

function mapStateToProps(state){
    return {
    users: state.users
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({get : get}, dispatch)
}


export default connect(mapStateToProps,matchDispatchToProps)(UserName);