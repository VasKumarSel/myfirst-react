import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {get} from '../actions/actions'

class UserDetails extends React.Component{
    render(){
        var Users = this.props.users.map((user1)=>(<li onClick={()=>this.props.get(user1)} key={user1.id}>{user1.firstname} <img src= {user1.image} /> {user1.lastname} {user1.description} </li>));

        return(
            <div>
                <h1>The details are:</h1>
                <h2>The details are: {Users}</h2>
                <img src={this.props.users.image} />
            </div>
        )
    }
}
 

function mapStateToProps(state){
    return{
        users : state.users
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({get : get}, dispatch)
}




export default connect(mapStateToProps,matchDispatchToProps)(UserDetails)